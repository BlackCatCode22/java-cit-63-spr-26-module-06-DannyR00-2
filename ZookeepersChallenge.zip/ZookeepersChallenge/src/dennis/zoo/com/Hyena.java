package dennis.zoo.com;

public class Hyena extends Animal {
    // This tracks how many hyenas we have created for the ID (Hy01, Hy02...)
    public static int numOfHyenas = 0;

    public Hyena(String sex, int age, int weight, String animalName,
                 String animalID, String animalBirthDate, String animalColor,
                 String animalOrigin, String animalArrivalDate) {
        // passes the data up to the Animal parent class
        super(sex, age, weight, animalName, animalID, animalBirthDate, animalColor, animalOrigin, animalArrivalDate);

        // Increment the counter every time a new Hyena is made
        numOfHyenas++;
    }
}