package dennis.zoo.com;

public class Tiger extends Animal {
    // This tracks how many tigers we have created
    public static int numOfTigers = 0;

    public Tiger(String sex, int age, int weight, String animalName,
                 String animalID, String animalBirthDate, String animalColor,
                 String animalOrigin, String animalArrivalDate) {
        // super() passes the data to the Animal parent class
        super(sex, age, weight, animalName, animalID, animalBirthDate, animalColor, animalOrigin, animalArrivalDate);
        numOfTigers++;
    }
}