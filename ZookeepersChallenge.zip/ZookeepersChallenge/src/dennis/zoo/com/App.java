package dennis.zoo.com;

import java.io.*;
import java.util.ArrayList;

public class App {
    public static void main(String[] args) {
        // 1. Load Names
        AnimalNameListsWrapper nameLists = Utilities.createAnimalNameLists("animalNames.txt");

        // 2. Prepare the separate Habitats (ArrayLists)
        ArrayList<Hyena> hyenaHabitat = new ArrayList<>();
        ArrayList<Lion> lionHabitat = new ArrayList<>();
        ArrayList<Tiger> tigerHabitat = new ArrayList<>();
        ArrayList<Bear> bearHabitat = new ArrayList<>();

        // 3. Read the arriving animals
        try (BufferedReader reader = new BufferedReader(new FileReader("arrivingAnimals.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                String[] words = parts[0].split(" ");

                int age = Integer.parseInt(words[0]);
                String sex = words[3];
                String species = words[4];

                // Get the extra details for the report
                String birthSeason = parts[1]; // e.g. "born in spring"
                String color = parts[2];       // e.g. "tan color"
                String weight = parts[3];      // e.g. "70 pounds"
                String origin = parts[4] + ", " + parts[5]; // e.g. "from Friguia Park, Tunisia"

                String id = Utilities.calcAnimalID(species);
                String bDay = Utilities.calcAnimalBirthDate(age, birthSeason);
                String arrivalDate = Utilities.getTodayDate();

                // Sort them into their specific lists
                if (species.equalsIgnoreCase("hyena")) {
                    String name = nameLists.getHyenaNameList().remove(0);
                    hyenaHabitat.add(new Hyena(sex, age, 70, name, id, bDay, color, origin, arrivalDate));
                } else if (species.equalsIgnoreCase("lion")) {
                    String name = nameLists.getLionNameList().remove(0);
                    lionHabitat.add(new Lion(sex, age, 150, name, id, bDay, color, origin, arrivalDate));
                } else if (species.equalsIgnoreCase("tiger")) {
                    String name = nameLists.getTigerNameList().remove(0);
                    tigerHabitat.add(new Tiger(sex, age, 200, name, id, bDay, color, origin, arrivalDate));
                } else if (species.equalsIgnoreCase("bear")) {
                    String name = nameLists.getBearNameList().remove(0);
                    bearHabitat.add(new Bear(sex, age, 300, name, id, bDay, color, origin, arrivalDate));
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading input files.");
        }

        // 4. GENERATE THE REPORT (zooPopulation.txt)
        try (PrintWriter writer = new PrintWriter(new FileWriter("zooPopulation.txt"))) {

            // Write Hyenas
            writer.println("Hyena Habitat:");
            for (Hyena h : hyenaHabitat) {
                writer.println(formatReportLine(h));
            }
            writer.println(); // Blank line between habitats

            // Write Lions
            writer.println("Lion Habitat:");
            for (Lion l : lionHabitat) {
                writer.println(formatReportLine(l));
            }
            writer.println();

            // Write Tigers
            writer.println("Tiger Habitat:");
            for (Tiger t : tigerHabitat) {
                writer.println(formatReportLine(t));
            }
            writer.println();

            // Write Bears
            writer.println("Bear Habitat:");
            for (Bear b : bearHabitat) {
                writer.println(formatReportLine(b));
            }

            System.out.println("Success! zooPopulation.txt has been generated.");

        } catch (IOException e) {
            System.out.println("Error writing the report.");
        }
    }

    // A helper method to make the report line look exactly like the "Expected Output"
    public static String formatReportLine(Animal a) {
        return a.getAnimalID() + "; " + a.getAnimalName() + "; birth date: " + a.getAnimalBirthDate() +
                "; " + a.getAnimalColor() + "; " + a.getSex() + "; " + a.getWeight() + " pounds; " +
                a.getAnimalOrigin() + "; arrived " + a.getAnimalArrivalDate();
    }
}