package dennis.zoo.com;

public class Lion extends Animal {
    public static int numOfLions = 0; // Counts how many lions exist

    public Lion(String sex, int age, int weight, String animalName,
                String animalID, String animalBirthDate, String animalColor,
                String animalOrigin, String animalArrivalDate) {
        // 'super' sends the data to the Animal class
        super(sex, age, weight, animalName, animalID, animalBirthDate, animalColor, animalOrigin, animalArrivalDate);
        numOfLions++; // Add 1 to the lion count
    }
}