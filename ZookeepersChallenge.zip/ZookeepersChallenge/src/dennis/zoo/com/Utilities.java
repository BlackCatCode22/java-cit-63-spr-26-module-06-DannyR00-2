package dennis.zoo.com;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utilities {

    // 1. Tool to create the Unique ID (Hy01, Li01, etc.)
    public static String calcAnimalID(String animalSpecies) {
        String myID = "";
        if (animalSpecies.equalsIgnoreCase("hyena")) {
            myID = "Hy0" + (Hyena.numOfHyenas + 1);
        } else if (animalSpecies.equalsIgnoreCase("lion")) {
            myID = "Li0" + (Lion.numOfLions + 1);
        } else if (animalSpecies.equalsIgnoreCase("tiger")) {
            myID = "Ti0" + (Tiger.numOfTigers + 1);
        } else if (animalSpecies.equalsIgnoreCase("bear")) {
            myID = "Be0" + (Bear.numOfBears + 1);
        }
        return myID;
    }

    // 2. Tool to calculate Birth Date in ISO 8601 (YYYY-MM-DD)
    public static String calcAnimalBirthDate(int age, String theSeason) {
        int birthYear = 2026 - age; // Midterm year
        String monthDay;

        switch (theSeason.toLowerCase()) {
            case "spring" -> monthDay = "-03-21";
            case "summer" -> monthDay = "-06-21";
            case "fall"   -> monthDay = "-09-21";
            case "winter" -> monthDay = "-12-21";
            default       -> monthDay = "-01-01"; // Default if unknown
        }
        return birthYear + monthDay;
    }

    // 3. Tool to get Today's Date
    public static String getTodayDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(new Date());
    }

    // 4. Tool to read animalNames.txt and organize them into the Wrapper
    public static AnimalNameListsWrapper createAnimalNameLists(String filePath) {
        ArrayList<String> hyenaNames = new ArrayList<>();
        ArrayList<String> lionNames = new ArrayList<>();
        ArrayList<String> tigerNames = new ArrayList<>();
        ArrayList<String> bearNames = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            ArrayList<String> currentList = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("Hyena")) currentList = hyenaNames;
                else if (line.startsWith("Lion")) currentList = lionNames;
                else if (line.startsWith("Tiger")) currentList = tigerNames;
                else if (line.startsWith("Bear")) currentList = bearNames;
                else if (!line.isEmpty() && currentList != null) {
                    String[] names = line.split(", ");
                    for (String name : names) currentList.add(name);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading names: " + e.getMessage());
        }
        return new AnimalNameListsWrapper(hyenaNames, lionNames, tigerNames, bearNames);
    }
}