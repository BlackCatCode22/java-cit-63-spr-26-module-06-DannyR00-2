package dennis.zoo.com;

public class Animal {
    // 1. Attributes
    private String sex;
    private int age;
    private int weight;
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalOrigin;
    private String animalArrivalDate;

    // 2. Constructor
    public Animal(String sex, int age, int weight, String animalName,
                  String animalID, String animalBirthDate, String animalColor,
                  String animalOrigin, String animalArrivalDate) {
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.animalName = animalName;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalOrigin = animalOrigin;
        this.animalArrivalDate = animalArrivalDate;
    }

    // 3. GETTERS (These allow App.java to "see" the data)

    public int getAge() {
        return age;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getAnimalID() {
        return animalID;
    }

    public String getSex() {
        return sex;
    }

    public int getWeight() {
        return weight;
    }

    public String getAnimalBirthDate() {
        return animalBirthDate;
    }

    public String getAnimalColor() {
        return animalColor;
    }

    public String getAnimalOrigin() {
        return animalOrigin;
    }

    public String getAnimalArrivalDate() {
        return animalArrivalDate;
    }
}